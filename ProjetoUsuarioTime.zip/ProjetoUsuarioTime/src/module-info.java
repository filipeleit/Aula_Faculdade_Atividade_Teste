/**
 * 
 */
/**
 * 
 */
module ProjetoUsuarioTime {
	requires java.desktop;
}