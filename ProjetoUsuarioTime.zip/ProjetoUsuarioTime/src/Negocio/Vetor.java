package Negocio;

import Modelagem.Usuario;

public class Vetor {
    public Usuario [] usuarios= new Usuario [3];
    
    
    public void CadastroUsuarioTime(int posicao, Usuario usuario) {
    	usuarios[posicao]=usuario;
    }
}
