package Visao;

import java.io.ObjectInputStream.GetField;
import java.lang.annotation.Target;

import javax.swing.JOptionPane;

import Modelagem.Usuario;
import Negocio.Vetor;

public class ClasseMainTime {

	public static void main(String[] args) {
		Usuario andre = new Usuario();
		andre.setNome(JOptionPane.showInputDialog(null,"Digite seu nome:"));
		andre.setCPF(JOptionPane.showInputDialog(null,"Digite seu cpf:"));
		andre.setTime(JOptionPane.showInputDialog(null,"Digite seu time:"));

	    JOptionPane.showMessageDialog(null,"nome usuario:"+andre.getNome()+"\n"+
	                      "CPF Cadastrado:"+andre.getCPF()+"\n"+"Time Favorito:"
	                      +andre.getTime()
	    		);
	}

}
